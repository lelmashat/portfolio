#ifndef LLREC_H
#define LLREC_H
#ifndef NULL
#define NULL 0
#endif

/**
 * Node struct for both problems
 */
struct Node
{
    int val;
    Node *next;

    Node(int v, Node* n) : val(v), next(n) {}
};

/**
 * Given a linked list pointed to by head, creates two lists
 * where all values less than or equal to the pivot value are
 * placed in a linked list whose head will be pointed to by
 * smaller and all values greater than the pivot
 * value are placed in a linked list whose head will be pointed to
 * by larger.  The input list pointed to by head should be empty
 * upon return and head set to NULL (i.e. we are not making copies)
 * in the smaller and larger lists but simply moving Nodes out of
 * the input list and into the two other lists.
 * 
 * ==============================================================
 * MUST RUN IN O(n) where n is the number of nodes in the input list
 * ==============================================================
 *
 * @pre: smaller and larger may containing garbage (do NOT have
 *       to be NULL)
 *
 * @param[inout] head
 *   Reference to the head pointer to the input list.
 *   Should be set to NULL upon return
 * @param[out] smaller
 *   Reference to a head pointer for the list of nodes with values
 *   less than or equal to the pivot
 * @param[out] larger
 *   Reference to a head pointer for the list of nodes with values
 *   greater than the pivot
 * @param[in] pivot
 *   Pivot value
 *
 */
void llpivot(Node *&head, Node *&smaller, Node *&larger, int pivot);

/**
 * Given a linked list pointed to by head, removes (filters out) nodes
 * whose value does not meet the criteria given by the predicate
 * function object, pred (i.e. pred should be a function object that implements
 * `bool operator()(int value)` and returns *true* for items that should
 * be *removed/filtered*.  Removed items should be deallocated.
 *
 * ==============================================================
 * MUST RUN IN O(n) where n is the number of nodes in the input list
 * ==============================================================
 *
 * @param[in] head
 *   Reference to the head pointer to the input list.
 * @param[in] pred
 *   Predicate object implementing: `bool operator()(int value)` that
 *   returns true if a node (based on its value) should be removed.
 * @return a head pointer to the resulting list (since the head pointer
 *   may change [i.e. be filtered])
 *
 */
/*
template <typename Comp>
Node* llfilter(Node* head, Comp pred) {
  // Base case: If the current node is nullptr (end of the list), return nullptr
  if (head == nullptr) {
      return nullptr;
  }

  // Initialize pointers for the new filtered list
  Node* filteredHead = nullptr;
  Node* filteredTail = nullptr;

  // Iterate through the original list
  while (head != nullptr) {
      // Store the current node in a separate pointer and move head node to next
      Node* current = head;
      head = head->next;

      // Check if the current node's value does not satisfy the predicate
      if (!pred(current->val)) {
          // Disconnect the current node from the original list and makes updates to list accordingly
          current->next = nullptr;
          if (filteredHead == nullptr) {
              filteredHead = current;
              filteredTail = current;
          } else {
              filteredTail->next = current;
              filteredTail = current;
          }
      } else {
          // If the current node's value satisfies the predicate, delete the node
          delete current;
      }
  }
  // Return the head of the new filtered list
  return filteredHead;
}
*/
template <typename Comp>
Node* llfilter(Node* head, Comp pred) {
    // Base case: If the current node is nullptr (end of the list), return nullptr
    if (head == nullptr) {
        return nullptr;
    }

    // Check if the current node's value does not satisfy the predicate
    if (!pred(head->val)) {
        // Disconnect the current node from the original list and makes updates to list accordingly
        Node* filteredHead = head;
        Node* filteredTail = head;
        head = head->next;
        filteredHead->next = nullptr;

        // Recursive call on the next node in the list, and update the filtered list
        Node* nextFiltered = llfilter(head, pred);
        if (nextFiltered != nullptr) {
            filteredTail->next = nextFiltered;
            filteredTail = nextFiltered;
        }

        return filteredHead;
    } else {
        // If the current node's value satisfies the predicate, delete the node and continue with the next node
        Node* temp = head;
        head = head->next;
        delete temp;

        // Recursive call on the next node in the list
        return llfilter(head, pred);
    }
}

#endif

